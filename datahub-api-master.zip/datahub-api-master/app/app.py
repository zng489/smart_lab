'''API General resources '''
