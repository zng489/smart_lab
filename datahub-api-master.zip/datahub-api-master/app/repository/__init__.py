''' Repository base module '''
